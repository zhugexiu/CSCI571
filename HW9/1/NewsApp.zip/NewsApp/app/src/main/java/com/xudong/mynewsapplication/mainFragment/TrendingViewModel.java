package com.xudong.mynewsapplication.mainFragment;

import androidx.lifecycle.ViewModel;

public class TrendingViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
