package com.xudong.mynewsapplication.mainFragment;

import androidx.lifecycle.ViewModel;

public class HeadlinesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
