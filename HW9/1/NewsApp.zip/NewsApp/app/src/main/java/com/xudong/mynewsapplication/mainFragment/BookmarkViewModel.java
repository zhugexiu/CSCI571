package com.xudong.mynewsapplication.mainFragment;

import androidx.lifecycle.ViewModel;

public class BookmarkViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
