package com.example.stockapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.stockapp.API.AutoSuggestAdapter;
import com.example.stockapp.API.ApiCall;
import com.example.stockapp.searchPage.SearchActivity;
import com.example.stockapp.searchPage.favoriteItem;
import com.example.stockapp.searchPage.mySharedPreference;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static android.widget.GridLayout.VERTICAL;

public class MainActivity extends AppCompatActivity {
    private AutoSuggestAdapter autoSuggestAdapter;
    private Handler handler;
    Toolbar toolbar;
    public static final String EXTRA_ID = "keyword";
    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;

    private ProgressBar progressBar;
    private TextView progressBar_Text;

    private RecyclerView recyclerView1;
    private RecyclerView recyclerView2;
    private ArrayList<favoriteItem> list = new ArrayList<>();
    private ArrayList<showFavoriteItem> newlist = new ArrayList<>();
    private mySharedPreference mySharedPreference;
    private boolean hasCreated = false;
    private FavoriteAdapter favoriteAdapter;
    private RequestQueue requestQueue;
    private List<favoriteItem> markedList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Make sure this is before calling super.onCreate
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar=findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);




        //favorite
        mySharedPreference = new mySharedPreference();
        requestQueue = VolleySingleton.getInstance(MainActivity.this).getmRequestQueue();
        //yihuo context
        list = mySharedPreference.getFavorites(this);

        progressBar= findViewById(R.id.progressBar_main);
        progressBar_Text = findViewById(R.id.textView_progressBar_main);
        progressBar.setVisibility(View.VISIBLE);
        progressBar_Text.setVisibility(View.VISIBLE);
        recyclerView1 = findViewById(R.id.recyclerView_F);
        recyclerView1.setVisibility(View.INVISIBLE);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 1);
        recyclerView1.setLayoutManager(gridLayoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView1.getContext(), VERTICAL);
        recyclerView1.addItemDecoration(dividerItemDecoration);

        favoriteAdapter = new FavoriteAdapter(MainActivity.this,list);
        hasCreated = true;


        Timer UiTimer = new Timer();
        UiTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(newlist != null) {
                            recyclerView1.setAdapter(favoriteAdapter);
                        }
                        progressBar.setVisibility(View.GONE);
                        progressBar_Text.setVisibility(View.GONE);
                        recyclerView1.setVisibility(View.VISIBLE);
                    }
                });
            }
        }, 5000); // End of your timer code.

    }

    public void onStart() {
        super.onStart();
        if (hasCreated){
//            Log.e(TAG,"在这刷新");
            favoriteAdapter.notifyAdapterDataSetChanged();
            checkNoBookmark();
        }
    }

    public void checkNoBookmark(){
        markedList = mySharedPreference.getFavorites(this);
        if (markedList == null || markedList.size() == 0){
            //noBookmark.setVisibility(View.VISIBLE);
        } else{
            //noBookmark.setVisibility(View.GONE);
        }

    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.search, menu);
        MenuItem searchItem =  menu.findItem(R.id.action_search);
        SearchView searchView = (androidx.appcompat.widget.SearchView)searchItem.getActionView();
        //get autocomplete
        final SearchView.SearchAutoComplete searchAutoComplete = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        searchAutoComplete.setThreshold(3);
        //searchAutoComplete.setTextCursorDrawable(R.drawable.searchbar_cursor);


        // Create a new ArrayAdapter and add data to search auto complete object.
        autoSuggestAdapter = new AutoSuggestAdapter(this,
                android.R.layout.simple_dropdown_item_1line);
        searchAutoComplete.setAdapter(autoSuggestAdapter);

        // Listen to search view item on click event.
        searchAutoComplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int itemIndex, long id) {
                String queryString=(String)adapterView.getItemAtPosition(itemIndex);
                searchAutoComplete.setText("" + queryString);
                Intent searchIntent = new Intent(MainActivity.this, SearchActivity.class);
                searchIntent.putExtra(EXTRA_ID, queryString);
                startActivity(searchIntent, ActivityOptions.makeSceneTransitionAnimation(MainActivity.this).toBundle());
//                Toast.makeText(MainActivity.this, "you clicked " + queryString, Toast.LENGTH_LONG).show();
            }
        });

        //Listen to enter key
        searchAutoComplete.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                String queryString;
                if (event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    switch (event.getAction()) {
                        case KeyEvent.ACTION_UP:
                            if (v.getText() != null && !v.getText().toString().equals("")){
                                queryString= "" + v.getText();
                                searchAutoComplete.setText(queryString);
                                Intent searchIntent = new Intent(MainActivity.this, SearchActivity.class);
                                searchIntent.putExtra(EXTRA_ID, queryString);
                                startActivity(searchIntent, ActivityOptions.makeSceneTransitionAnimation(MainActivity.this).toBundle());
                            }
                            else
                                Toast.makeText(MainActivity.this, "you need to enter a keyword", Toast.LENGTH_SHORT).show();
                            return true;
                        default:
                            return true;
                    }
                }
                return false;
            }
        });

        searchAutoComplete.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                handler.removeMessages(TRIGGER_AUTO_COMPLETE);
                handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                        AUTO_COMPLETE_DELAY);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
                        makeApiCall(searchAutoComplete.getText().toString());
                    }
                }
                return false;
            }
        });
        return true;
    }


    private void makeApiCall(String text) {
        ApiCall.make(this, text, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //parsing logic, please change it as per your requirement
                List<String> stringList = new ArrayList<>();
                try {
                    JSONObject responseObject = new JSONObject(response);
                    JSONArray array = responseObject
                            .getJSONArray("suggestionGroups")
                            .getJSONObject(0)
                            .getJSONArray("searchSuggestions");
                    for (int i = 0; i < 5; i++) {
                        JSONObject row = array.getJSONObject(i);
                        stringList.add(row.getString("displayText"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //IMPORTANT: set data here and notify
                autoSuggestAdapter.setData(stringList);
                autoSuggestAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
    }


}