package com.example.stockapp.searchPage;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.transition.Slide;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.stockapp.R;
import com.example.stockapp.VolleySingleton;
import com.example.stockapp.card.NewsCardsAdapter;
import com.example.stockapp.card.NewsItem;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import static android.widget.LinearLayout.VERTICAL;



public class SearchActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "keyword";
    private static final String TAG = "hello";

    private RecyclerView recyclerView;
    private NewsCardsAdapter newsCardsAdapter;
    private ArrayList newsItemArrayList;
    private RequestQueue requestQueue;

    private boolean hasCreated = false;
    private String keyword;
    private TextView textViewSearch;
    private TextView textViewProgressBar;

    private ProgressBar progressBar;
    private ImageView imageViewBack;
    private ScrollView scrollViewDetail;

    //展现的东西
    private TextView ticker;
    private TextView name;
    private TextView price;
    private TextView changeprice;
    private WebView WebView;
    private TextView desc;
    private TextView show;
    private boolean isshow;
    private GridView simpleList;
    private ArrayList list=new ArrayList<>();

    private TextView resfirst;
    private TextView titlefirst;
    private TextView timefirst;
    private ImageView imagefirst;
    private CardView cardView1;

    private mySharedPreference mSharedPreference;
    private ImageButton imageButton;

    private favoriteItem favoriteItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        getWindow().setEnterTransition(new Slide().setDuration(500));
        getWindow().setExitTransition(new Slide());
        setContentView(R.layout.activity_search);

        //获取keyword
        Intent intent = getIntent();
        keyword = intent.getStringExtra(EXTRA_ID);

        mSharedPreference = new mySharedPreference();
        scrollViewDetail = findViewById(R.id.ScrollView_detail);
        WebView = findViewById(R.id.WebView);
        cardView1 = findViewById(R.id.CardView1);

        textViewSearch = findViewById(R.id.textView_search);
        imageViewBack = findViewById(R.id.imageView_getBack);
        textViewProgressBar = findViewById(R.id.textView_progressBar_search);
        progressBar = findViewById(R.id.progressBar_search);
        progressBar.setVisibility(View.VISIBLE);
        textViewProgressBar.setVisibility(View.VISIBLE);
        scrollViewDetail.setVisibility(View.INVISIBLE);

        imageButton = findViewById(R.id.imageButton);
        imageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String tag = imageButton.getTag().toString();
                if (tag.equals("no")){
                    mSharedPreference.addFavorite(SearchActivity.this, favoriteItem);
                    Toast.makeText(SearchActivity.this, "\"" + favoriteItem.getfavoriteItem()
                            +"\" was added to favorites", Toast.LENGTH_SHORT).show();
                    imageButton.setTag("yes");
                    Drawable bookmarked = ResourcesCompat.getDrawable(v.getResources(), R.drawable.ic_baseline_star_24, null);
                    imageButton.setBackground(bookmarked);
                }else {
                    mSharedPreference.removeFavorite(SearchActivity.this, favoriteItem);
                    Toast.makeText(SearchActivity.this, "\"" + favoriteItem.getfavoriteItem()
                            +"\" was removed from favorites", Toast.LENGTH_SHORT).show();
                    imageButton.setTag("no");
                    Drawable no_bookmarked = ResourcesCompat.getDrawable(v.getResources(), R.drawable.ic_baseline_star_border_24, null);
                    imageButton.setBackground(no_bookmarked);
                }
            }
        });





        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        recyclerView = findViewById(R.id.recycleView_search);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);
        newsItemArrayList = new ArrayList<>();

        //mAdapter = new MyAdapter(myDataset);
        //recyclerView.setAdapter(mAdapter);
        ticker = findViewById(R.id.ticker);
        name = findViewById(R.id.name);
        price = findViewById(R.id.price);
        changeprice = findViewById(R.id.changeprice);
        desc = findViewById(R.id.description);
        show = findViewById(R.id.show);

        imagefirst = findViewById(R.id.imageViewfirst);
        resfirst = findViewById((R.id.resfirst));
        titlefirst = findViewById(R.id.titlefirst);
        timefirst = findViewById(R.id.timefirst);

        desc.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Log.e(TAG, "行数"+desc.getLineCount());
                if(desc.getLineCount()>2){
                    desc.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    desc.setEllipsize(TextUtils.TruncateAt.END);//收起
                    desc.setLines(2);
                    show.setText("Show more..");
                    isshow = false;
                }else{
                    show.setText(null);
                }
            }
        });

        requestQueue = VolleySingleton.getInstance(SearchActivity.this).getmRequestQueue();

        parseDetail();
        parsePrice();
        parseStats();

        WebSettings settings = WebView.getSettings();
        settings.setJavaScriptEnabled(true);
        WebView.clearCache(true);
        settings.setDomStorageEnabled(true);
        WebView.setWebViewClient(new WebViewClient());
        WebView.loadUrl("file:///assets/chart.html");

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isshow)
                {
                    //isshow=false;
                    desc.setEllipsize(TextUtils.TruncateAt.END);//收起
                    desc.setLines(2);
                    show.setText("Show more..");
                }else
                {
                    // isshow=true;
                    //  tv_des.setEllipsize(TextUtils.TruncateAt.END);//收起
                    desc.setEllipsize(null);//展开
                    desc.setSingleLine(false);//这个方法是必须设置的，否则无法展开
                    show.setText("Show less");
                }
                isshow=!isshow;
            }
        });

        parseNews();

        //gridview
        simpleList = findViewById(R.id.simpleGridView);


        Timer UiTimer = new Timer();
        UiTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        parseDetail();
                        parsePrice();
                        textViewProgressBar.setVisibility(View.GONE);
                        progressBar.setVisibility(View.GONE);
                        scrollViewDetail.setVisibility(View.VISIBLE);
                    }
                });
            }
        }, 5000); // End of your timer code.

    }

    private void parseDetail() {
        String url = "http://zhugexiu.us-east-1.elasticbeanstalk.com/details/" + keyword;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, response -> {
            try {
                JSONObject jsonObject = response.getJSONObject("description");
                String Jsonticker = jsonObject.getString("ticker");
                String Jsonname = jsonObject.getString("name");
                String Jsondesc = jsonObject.getString("description");
                ticker.setText(Jsonticker);
                name.setText(Jsonname);
                desc.setText(Jsondesc);
                favoriteItem = new favoriteItem(Jsonticker,Jsonname);

                if (checkBookmarkItem(favoriteItem)){
                    imageButton.setTag("yes");
                    Drawable bookmarked = ResourcesCompat.getDrawable(getResources(), R.drawable.ic_baseline_star_24, null);
                    imageButton.setBackground(bookmarked);
                } else {
                    imageButton.setTag("no");
                    Drawable no_bookmarked = ResourcesCompat.getDrawable(getResources(), R.drawable.ic_baseline_star_border_24, null);
                    imageButton.setBackground(no_bookmarked);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, Throwable::printStackTrace);
        requestQueue.add(request);
    }

    private void parsePrice() {
        String url = "http://zhugexiu.us-east-1.elasticbeanstalk.com/price/" + keyword;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, response -> {
            try {
                JSONArray jsonArray = response.getJSONArray("description");
                JSONObject jsonObject = jsonArray.getJSONObject(0);
                String Jsonprice = "$" + jsonObject.getString("last");
                price.setText(Jsonprice);
                String Jsonprice2 = jsonObject.getString("prevClose");
                double last = Double.parseDouble(jsonObject.getString("last"));
                double prev = Double.parseDouble(Jsonprice2);
                double c = last-prev;
                if(c==0){
                    String s1 = "$"+String.format("%.2f", c);
                    changeprice.setText(Html.fromHtml("<font color='gray'>" + s1 + "</font>"));
                }else if(c > 0) {
                    String s2 = "$"+String.format("%.2f", c);
                    changeprice.setText(Html.fromHtml("<font color='green'>" + s2 + "</font>"));
                }else{
                    String s3 = "-$"+String.format("%.2f", Math.abs(c));
                    changeprice.setText(Html.fromHtml("<font color='red'>" + s3 + "</font>"));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, Throwable::printStackTrace);
        requestQueue.add(request);
    }

    private void parseStats() {
        String url = "http://zhugexiu.us-east-1.elasticbeanstalk.com/price/" + keyword;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, response -> {
            try {
                JSONArray jsonArray = response.getJSONArray("description");
                JSONObject jsonObject = jsonArray.getJSONObject(0);
                list.add(new Item("Current Price: "+jsonObject.getString("last")));
                list.add(new Item("Low: "+jsonObject.getString("low")));
                list.add(new Item("Bid Price: "+jsonObject.getString("bidPrice")));
                list.add(new Item("Open Price: "+jsonObject.getString("open")));
                list.add(new Item("Mid: "+jsonObject.getString("mid")));
                list.add(new Item("High: "+jsonObject.getString("high")));
                list.add(new Item("Volume: "+jsonObject.getString("volume")));
                Log.d(TAG, "hhhhhhhhhh"+1);
                MyAdapter myAdapter = new MyAdapter(this,R.layout.grid_view_items,list);
                simpleList.setAdapter(myAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, Throwable::printStackTrace);
        requestQueue.add(request);
    }

    private void parseNews() {
        String url = "http://zhugexiu.us-east-1.elasticbeanstalk.com/hw9news/" + keyword;
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONObject firstres = response.getJSONObject(0);
                        String u = firstres.getString("urlToImage");
                        String URL = firstres.getString("url");
                        String res1 = firstres.getJSONObject("source").getString("name");
                        String title1 = firstres.getString("title");
                        String time1 = getFormattedTime(firstres.getString("publishedAt"));
                        Picasso.get().load(u).fit().centerInside().into(imagefirst);
                        resfirst.setText(firstres.getJSONObject("source").getString("name"));
                        titlefirst.setText(firstres.getString("title"));
                        timefirst.setText(getFormattedTime(firstres.getString("publishedAt")));

                        titlefirst.setOnClickListener(v1 -> {
                            Intent intent = new Intent();
                            intent.setData(Uri.parse(URL));
                            intent.setAction(Intent.ACTION_VIEW);
                            this.startActivity(intent);
                        });

                        cardView1.setOnLongClickListener(new View.OnLongClickListener() {
                            @Override
                            public boolean onLongClick(View v) {
                                final NewsItem clickedItem = new NewsItem(u, title1, time1, URL, res1);
                                Dialog dialog = new Dialog(v.getContext());
                                dialog.setContentView(R.layout.dialog);
                                ImageView imageViewDialog = dialog.findViewById(R.id.imageView_dialogPic);
                                TextView textViewDialog = dialog.findViewById(R.id.textViewDialog);
                                ImageView imageViewTwitter = dialog.findViewById(R.id.imageView_dialogTwitter);
                                ImageView imageViewChrome = dialog.findViewById(R.id.imageView_dialogChrome);

                                Picasso.get().load(clickedItem.getImageUrl()).fit().centerInside().into(imageViewDialog);
                                textViewDialog.setText(clickedItem.getSummary());
                                imageViewTwitter.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet?text=Check out this Link: "
                                                + clickedItem.getmWebUrl() + "&hashtags=CSCI571NEWS"));
                                        startActivity(intent);
                                    }
                                });
                                imageViewChrome.setOnClickListener(v1 -> {
                                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse( clickedItem.getmWebUrl()));
                                        startActivity(intent);
                                });
                                dialog.show();
                                return true;
                            }
                        });


                        for (int i = 1; i < response.length(); i++) {
                            JSONObject result = response.getJSONObject(i);
                            String imageUrl = result.getString("urlToImage");
                            String summary = result.getString("title");
                            String time = result.getString("publishedAt");
                            String webUrl = result.getString("url");
                            String res = result.getJSONObject("source").getString("name");
                            newsItemArrayList.add(new NewsItem(imageUrl, summary, time, webUrl, res));
                        }
                        newsCardsAdapter = new NewsCardsAdapter(SearchActivity.this, newsItemArrayList);
                        recyclerView.setAdapter(newsCardsAdapter);
                        recyclerView.setVisibility(View.VISIBLE);
                        hasCreated = true;
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }, Throwable::printStackTrace
        );
        requestQueue.add(request);
    }

    private String getFormattedTime(String oTime){
        String str = "";
        String suffix = "ago";

        Date nowTime = new Date();
        Instant instant = Instant.parse(oTime);
        ZoneId z = ZoneId.of( "America/Los_Angeles" );
        ZonedDateTime zdt = instant.atZone(z);
        Date newsTime = Date.from(zdt.toInstant());
        long dateDiff = nowTime.getTime() - newsTime.getTime();
        long second = TimeUnit.MILLISECONDS.toSeconds(dateDiff);
        long minute = TimeUnit.MILLISECONDS.toMinutes(dateDiff);
        long hour   = TimeUnit.MILLISECONDS.toHours(dateDiff);
        long day  = TimeUnit.MILLISECONDS.toDays(dateDiff);
        if (second < 60) {
            str = second+"s "+suffix;
        } else if (minute < 60) {
            str = minute+"m "+suffix;
        } else if (hour < 24) {
            str = hour+"h "+suffix;
        } else{
            str = day+"d "+suffix;
        }
        return str;
    }

    public boolean checkBookmarkItem(favoriteItem newsItem){
        boolean check = false;
        List<favoriteItem> BookmarkedItemsInSharedPreference = mSharedPreference.getFavorites(SearchActivity.this);
        if (BookmarkedItemsInSharedPreference != null) {
            for (favoriteItem news : BookmarkedItemsInSharedPreference) {
                if (news.equals(newsItem)) {
                    check = true;
                    break;
                }
            }
        }
        return check;
    }

}
