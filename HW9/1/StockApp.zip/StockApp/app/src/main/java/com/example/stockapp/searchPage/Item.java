package com.example.stockapp.searchPage;

public class Item {

    String stats;

    public Item(String s)
    {
        this.stats=s;
    }
    public String getbirdName()
    {
        return stats;
    }
}